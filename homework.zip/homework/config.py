import os

basedir = os.path.abspath(os.path.dirname(__file__))

# give access to the project in any operating system we find ourselves in
# Allows outside files/folders to be added to the project
# from the base directory

class Config():
    """
    Set Config variables for the flask app
    Using environment variables where available otherwise
    creates the config variable if not done already
    """

    SECRET_KEY = os.environ.get('SECRET KEY') or "ah ah ah, you didn't say the magic word."
    SQLALCHEMY_DATABASE_URL = os.environ.get('DATABASE_URL') or 'sqlite: ///' + os.path.join(basedir, 'app.db')
    SQUALCHEMY_TRACK_MODIFICATIONS = False # Turn off update messages